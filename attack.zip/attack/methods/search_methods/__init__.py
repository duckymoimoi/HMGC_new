from .greedy_dual_wir import GreedyDualWIR
